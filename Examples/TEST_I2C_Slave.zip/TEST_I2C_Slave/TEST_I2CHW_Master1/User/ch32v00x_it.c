/********************************** (C) COPYRIGHT *******************************
 * File Name          : ch32v00x_it.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2023/12/25
 * Description        : Main Interrupt Service Routines.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for 
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/
#include <ch32v00x_it.h>
#include "SSS_Common_Lib_V1/sss_fastGpio_lib1.h"

/* static const PinDefine_t LED1_PORT = {  // PA2 (выв 3)
    .rcc = RCC_APB2Periph_GPIOA,
    .port = GPIOA,
    .pin = GPIO_Pin_2
}; */

void NMI_Handler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void HardFault_Handler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

/*********************************************************************
 * @fn      NMI_Handler
 *
 * @brief   This function handles NMI exception.
 *
 * @return  none
 */
void NMI_Handler(void)
{
  while (1)
  {
  }
}

/*********************************************************************
 * @fn      HardFault_Handler
 *
 * @brief   This function handles Hard Fault exception.
 *
 * @return  none
 */
void HardFault_Handler(void)
{
    // Включаем диод намертво (или наоборот гасим), чтобы подать сигнал бедствия
    // Если диод загорается ИМЕННО после выхода из SendByte — это 100% HardFault
    // Настройка порта LED
    //fgpio_openPin (&LED1_PORT, GPIO_Mode_Out_PP);
    //fgpio_setPin (&LED1_PORT, 0);

  NVIC_SystemReset();
  while (1)
  {
  }
}


