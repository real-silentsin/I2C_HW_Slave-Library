/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2023/12/25
 * Description        : Main program body.
 *********************************************************************************
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * Attention: This software (modified or not) and binary are used for
 * microcontroller manufactured by Nanjing Qinheng Microelectronics.
 *******************************************************************************/

/*
 *  SDA     PC1
 *  SCL     PC2
 *
 *
 *
 */
// ----------------------------------------------------------------------------
#include "debug.h"
#include "SSS_Common_Lib_V1/sss_fastGpio_lib1.h"
#include "SSS_I2CHW_Master_Lib_V4.5/i2c.h"
#include "SSS_PA1_2_LIB1/sss_pa1_2_lib1.h"
// ----------------------------------------------------------------------------
/* Global typedef */
// ----------------------------------------------------------------------------
/* Global define */
#define SLAVE_I2C_ADDR 0x28

static const PinDefine_t KEY1_PORT = {  // PC4 (выв 7)
    .rcc = RCC_APB2Periph_GPIOC,
    .port = GPIOC,
    .pin = GPIO_Pin_4};

static const PinDefine_t LED1_PORT = {  // PA2 (выв 3)
    .rcc = RCC_APB2Periph_GPIOA,
    .port = GPIOA,
    .pin = GPIO_Pin_2};

// ----------------------------------------------------------------------------
/* Global Variable */
// ----------------------------------------------------------------------------
void SendByte() {
    // Передача ведомому 32-битного адреса

    // 0xFF - команда приема адреса
    // 0x10203040 (в обратном порядке)
    uint8_t data[5] = { 0xFF, 0x40, 0x30, 0x20, 0x10 };
    i2c_write(SLAVE_I2C_ADDR, data, 5);

    fgpio_setPin (&LED1_PORT, 1);
    Delay_Ms (1000);
    fgpio_setPin (&LED1_PORT, 0);
    Delay_Ms (1000);

    // Установка адреса 0
    data[0] = 0xFF;
    data[1] = 0x00;
    data[2] = 0x00;
    data[3] = 0x00;
    data[4] = 0x00;

    i2c_write (SLAVE_I2C_ADDR, data, 5);

    fgpio_setPin (&LED1_PORT, 1);
    Delay_Ms (1000);
    fgpio_setPin (&LED1_PORT, 0);
    Delay_Ms (1000);

    // Чтение из ведомого
    uint8_t tst_buf[3] = {0};
    i2c_read(SLAVE_I2C_ADDR, tst_buf, 3);

    if (tst_buf[0] == 0xAA && tst_buf[1] == 0xBB && tst_buf[2] == 0xCC) {

        for (int i = 0; i < 4; i++) {

            fgpio_setPin (&LED1_PORT, 1);
            Delay_Ms (1000);
            fgpio_setPin (&LED1_PORT, 0);
            Delay_Ms (1000);
        }
    }
}
// ----------------------------------------------------------------------------
/* void SendByte()  // Оставляем старое название функции, чтобы ничего не ломать в main
{
    // Буфер, куда Мастер тупо вслепую запишет то, что выудит из Слейва
    uint8_t rx_packet[3] = {0, 0, 0};

    // Вызываем ваш штатный i2c_read для чтения 3-х байт
    // Он сделает СТАРТ, отправит адрес на ЧТЕНИЕ, заберет 3 байта и сделает СТОП
    uint32_t last_err = i2c_read (SLAVE_I2C_ADDR, rx_packet, 3);

    if (last_err != I2C_ERROR_SUCCESS) {
        // Ошибка чтения
        fgpio_setPin (&LED1_PORT, 1);
    }

    if (rx_packet[0] == 0xAA && rx_packet[1] == 0xBB && rx_packet[2] == 0xCC) {

        for (int i = 0; i < 4; i++) {

            fgpio_setPin (&LED1_PORT, 1);
            Delay_Ms(1000);
            fgpio_setPin (&LED1_PORT, 0);
            Delay_Ms(1000);
        }
    }
} */
// ----------------------------------------------------------------------------
/* // Отправляем тестовый массив данных
void SendByte() {

    // Log: d5 a1 d5 88 11 d5 88 22 d5 88 33 d5 ff

    uint8_t tx_packet[] = {0x11, 0x22, 0x33};

    // Отправляем адрес Слейва, указатель на массив и count = 3 байта
    // Метод i2c_write внутри себя будет циклично вызывать i2c_send_byte,
    // а в конце выдаст честный STOP.
    uint32_t last_err = i2c_write (SLAVE_I2C_ADDR, tx_packet, 3);

    if (last_err != I2C_ERROR_SUCCESS) {
        // Ошибка, если Слейв не ответил ACK на адрес
    }
} */
// ----------------------------------------------------------------------------
/* // Отправка байта
void SendByte()
{
    uint8_t data = 0x55;
    uint32_t last_err = i2c_write(SLAVE_I2C_ADDR, &data, 1);
    if (last_err != I2C_ERROR_SUCCESS) {
        //printf ("I2C Master error: no slave\r\n");
    } else {
        //printf ("I2C Master: send success!\r\n");
    }
} */
// ----------------------------------------------------------------------------

/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
int main (void) {
    NVIC_PriorityGroupConfig (NVIC_PriorityGroup_1);
    SystemCoreClockUpdate();
    Delay_Init();

    //SDI_Printf_Enable();

    //printf ("SystemClk:%d\r\n", SystemCoreClock);
    //printf ("ChipID:%08x\r\n", DBGMCU_GetCHIPID());

    // Отключение кварца
    SSS_PA1_2_GPIO_Init();

    // Инициализация I2C
    IIC_Init (I2C_SPEED_FAST_MODE, I2C_SELF_ADDRESS);

    // Настройка PC4 на подтянутый к + вход для кнопки
    fgpio_openPin (&KEY1_PORT, GPIO_Mode_IPU);

    // Настройка порта LED
    fgpio_openPin (&LED1_PORT, GPIO_Mode_Out_PP);
    fgpio_setPin (&LED1_PORT, 0);

    //printf ("I2C Master started...\r\n");

    i2c_scan();

    while (1) {

        // Нажата кнопка
        if (fgpio_getPin (&KEY1_PORT) == 0) {

            // printf ("I2C Key pressed!\r\n");
            fgpio_setPin (&LED1_PORT, 1);

            SendByte();

            Delay_Ms (3000);
        }

        fgpio_setPin (&LED1_PORT, 0);
        Delay_Ms (500);
    }
}
