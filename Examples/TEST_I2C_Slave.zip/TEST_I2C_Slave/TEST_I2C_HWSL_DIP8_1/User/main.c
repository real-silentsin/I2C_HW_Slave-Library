/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2023/12/25
 * Description        : Main program body.
 *********************************************************************************
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * Attention: This software (modified or not) and binary are used for 
 * microcontroller manufactured by Nanjing Qinheng Microelectronics.
 *******************************************************************************/
// ----------------------------------------------------------------------------
#include "app_config.h"
#include "debug.h"
#include "SSS_I2C_HWSL_Lib_V1/sss_i2c_hwsl_lib_v1.h"
// ----------------------------------------------------------------------------
// Эти данные будет читать/записывать ведущий шины
volatile uint8_t my_telemetry[3] = {0xAA, 0xBB, 0xCC};
// ----------------------------------------------------------------------------
// Главный метод приложения
int main(void)
{
    //  -----------------------------------------------------------------------
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
    SystemCoreClockUpdate();

    Delay_Init();
    //SDI_Printf_Enable();
    //  -----------------------------------------------------------------------
    //printf("SystemClk:%d\r\n", SystemCoreClock);
    //printf("ChipID:%08x\r\n", DBGMCU_GetCHIPID());
    //  -----------------------------------------------------------------------
    i2c_slave_Init (I2C_SLAVE_SELF_ADDRESS, I2C_SPEED_FAST_MODE);
    //  -----------------------------------------------------------------------
    // 2. СВЯЗЫВАЕМ НАШ МАССИВ С БИБЛИОТЕКОЙ!
    // Передаем адрес массива и его размер.
    // sizeof(my_telemetry) вернет честные 6 байт (3 элемента по 2 байта)
    I2C_Slave_Link_Data ((void *)my_telemetry, sizeof (my_telemetry));
    //  -----------------------------------------------------------------------
    printf ("I2C_Slave Running!\r\n");
    //  -----------------------------------------------------------------------
    while (1) {
#ifdef I2C_SLAVE_LOG_ENABLED
        uint8_t l_size = log_getSize();

        if (l_size > 0) {
            printf ("Log: ");
            for (int i = 0; i < l_size; i++) {
                printf ("%02x ", log_getItem (i));
            }

            printf ("\r\n");

            log_reset();
        }

        Delay_Ms (2000);
#else
        Delay_Ms(500);
#endif
    }
}
// ----------------------------------------------------------------------------
